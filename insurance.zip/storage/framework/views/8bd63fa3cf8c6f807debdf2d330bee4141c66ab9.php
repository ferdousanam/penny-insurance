<?php $__env->startSection('title','User List'); ?>


<?php $__env->startPush('css'); ?>
    <!-- iCheck -->
    <link href="<?php echo e(asset('backend/vendors/iCheck/skins/flat/green.css')); ?>" rel="stylesheet">
<?php $__env->stopPush(); ?>


<?php $__env->startSection('content'); ?>
    <div class="right_col" role="main">
        <div class="">
            <div class="page-title">
                <div class="title_left">
                    <h3>Users</h3>
                </div>

                <div class="clearfix"></div>
                <div class="row">
                    <div class="col-md-12 col-sm-12 col-xs-12">
                        <div class="x_panel">
                            <div class="x_title">
                                <h2>Users List</h2>
                                <div class="clearfix"></div>
                            </div>

                            <div class="x_content">

                                <p>Add class <code>bulk_action</code> to table for bulk actions options on row select
                                </p>

                                <div class="table-responsive">
                                    <table class="table table-striped jambo_table bulk_action">
                                        <thead>
                                        <tr class="headings">
                                            <th>
                                                <input type="checkbox" id="check-all" class="flat">
                                            </th>
                                            <th class="column-title">User Name</th>
                                            <th class="column-title">First Name</th>
                                            <th class="column-title">Last Name</th>
                                            <th class="column-title">Status</th>
                                            <th class="column-title">Role</th>
                                            <th class="column-title no-link last"><span class="nobr">Action</span>
                                            </th>
                                            <th class="bulk-actions" colspan="7">
                                                <a class="antoo" style="color:#fff; font-weight:500;">Bulk Actions (
                                                    <span class="action-cnt"> </span> )
                                                    <i class="fa fa-chevron-down"></i></a>
                                            </th>
                                        </tr>
                                        </thead>

                                        <tbody>
                                        <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr class="even pointer">
                                            <td class="a-center ">
                                                <input type="checkbox" class="flat" name="table_records">
                                            </td>
                                            <td class=" "><?php echo e($user->username); ?></td>
                                            <td class=" "><?php echo e($user->first_name); ?></td>
                                            <td class=" "><?php echo e($user->last_name); ?></td>
                                            <td class="a-right a-right ">Active</td>
                                            <td class=" "><?php echo e($user->role->name); ?></td>
                                            <td class=" last"><a href="#">View</a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>
                                    </table>
                                </div>


                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startPush('scripts'); ?>
    <!-- iCheck -->
    <script src="<?php echo e(asset('backend/vendors/iCheck/icheck.min.js')); ?>"></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('backend.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\office\insurance\resources\views/backend/users/index.blade.php ENDPATH**/ ?>